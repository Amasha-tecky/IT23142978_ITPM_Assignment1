const { test, expect } = require('@playwright/test');

// Configuration
const CONFIG = {
  url: 'https://www.swifttranslator.com/',
  timeouts: {
    pageLoad: 2000,
    afterClear: 1000,
    translation: 3000,
    betweenTests: 2000
  },
  selectors: {
    inputField: 'Input Your Singlish Text Here.',
    outputContainer: 'div.w-full.h-80.p-3.rounded-lg.ring-1.ring-slate-300.whitespace-pre-wrap'
  }
};

// Test Data - Completely New Test Cases
const TEST_DATA = {
  positive: [
    
    {
      tcId: 'Pos_Fun_0001',
      name: ' Simply short  question',
      input: 'oya hodhin nedha?',
      expected: 'ඔය හොදින් නේද?',
    },

    
    {
      tcId: 'Pos_Fun_0002',
      name: 'Simple request',
      input: 'mata kanna oonee.',
      expected: 'මට කන්න ඕනේ.',
      
    },
    {
      tcId: 'Pos_Fun_0003',
      name: 'Convert a short sentense with Units of measurements ',
      input: 'mama 1kg k bara adu kara gaththaa',
      expected: 'මම 1kg ක් බර අඩු කර ගත්තා',
      
    },
    
    
    {
      tcId: 'Pos_Fun_0004',
      name: 'Complex sinhala words',
      input: 'sauKYA seevaava hodhayi.',
      expected: 'සෞඛ්‍ය සේවාව හොදයි.',
    },

    
    {
      tcId: 'Pos_Fun_0005',
      name: 'Frequently used day-to-day expressions/Slangs',
      input: 'anee hodhaa',
      expected: 'අනේ හොදා',
      
    },
    
    
    {
      tcId: 'Pos_Fun_0006',
      name: ' Imperative (commands) forms ',
      input: 'ehaata venna',
      expected: 'එහාට වෙන්න',
    },
    
    
    {
      tcId: 'Pos_Fun_0007',
      name: 'Convert a short phrase with English brand terms',
      input: 'maQQ eyaata skype call ekk gaththaa',
      expected: 'මං එයාට skype call එක්ක් ගත්තා',
    },
    {
      tcId: 'Pos_Fun_0008',
      name: 'Negation patterns',
      input: 'maQQ eeva kanna aasa naee.',
      expected: 'මං ඒව කන්න ආස නෑ.',
    },
    {
      tcId: 'Pos_Fun_0009',
      name: 'Positive forms',
      input: 'mama ee dhee karanavaa',
      expected: 'මම ඒ දේ කරනවා',
    },
    
    {
      tcId: 'Pos_Fun_0010',
      name: 'Common greetings',
      input: 'suba raathriyak veevaa!',
      expected: 'සුබ රාත්‍රියක් වේවා!',
    },
    
    
    {
      tcId: 'Pos_Fun_0011',
      name: 'Convert  request phrase',
      input: 'oyaata puluvandha tikak mata meekata udhav karanna?',
      expected: 'ඔයාට පුලුවන්ද ටිකක් මට මේකට උදව් කරන්න?',
    },
    //this is negative one
    /*{
      tcId: 'Pos_Fun_012',
      name: 'Convert a short responses phrase',
      input: 'hari man udhav karannam',
      expected: 'හරි මන් උදව් කරන්නම්',
    },*/
    
    
    {
      tcId: 'Pos_Fun_0012',
      name: ' Request forms with varying degrees of politeness + Multiple spaces',
      input: 'dhan nam baee. Heta karamu.',
      expected: 'දන් නම් බෑ. හෙට කරමු.',
    },
    {
      tcId: 'Pos_Fun_0013',
      name: 'Polite phrasing',
      input: 'Samaavenna, mama boruvata kivvee.',
      expected: 'සමාවෙන්න, මම බොරුවට කිව්වේ.',
    },
    
    {
      tcId: 'Pos_Fun_0014',
      name: ' responses with  punctuation marks',
      input: 'anee pav!',
      expected: 'අනේ පව්!',
      
    },

    {
      tcId: 'Pos_Fun_0015',
      name: 'Informal phrasing',
      input: 'adoo eka patta rahayi',
      expected: 'අඩෝ එක පට්ට රහයි',
    },
    
    
    {
      tcId: 'Pos_Fun_0016',
      name: 'Frequently used day-to-day expressions',
      input: 'pudhuma rasnayak thiyenne',
      expected: 'පුදුම රස්නයක් තියෙන්නෙ',
    },
    {
      tcId: 'Pos_Fun_0017',
      name: 'Multi-word expressions + frequent collocations',
      input: 'maQQ vaedak',
      expected: 'මං වැඩක්',
      
    },
    
  
    {
      tcId: 'Pos_Fun_0018',
      name: 'Repeated word expressions',
      input: 'haako haako',
      expected: 'හාකො හාකො',
      
    },
    
    
    {
      tcId: 'Pos_Fun_0019',
      name: 'past Tense variations',
      input: 'eyaalaa edhaa avaa',
      expected: 'එයාලා එදා අවා',
    },
    
    
    {
      tcId: 'Pos_Fun_0020',
      name: 'informal phrasing ',
      input: 'adee eeka balahanko',
      expected: 'අඩේ ඒක බලහන්කො',
    },
    {
      tcId: 'Pos_Fun_0021',
      name: 'Currency measurement + English short forms ',
      input: 'eeka mama USD 5000kata gaththee',
      expected: 'ඒක මම USD 5000කට ගත්තේ',
    },
    
    
    {
      tcId: 'Pos_Fun_0022',
      name: 'Slang and colloquial phrasing + english words that normally used',
      input: 'thanks machan!',
      expected: 'thanks මචන්!',
    },
    
    
    {
      tcId: 'Pos_Fun_0023',
      name: 'English abbreviations+ Medium letters',
      input: 'ee form eke lokuvata puravanna dheyak naee. CV eka upload karala oyaage NIC number eka wage personal details tikak puravanna tiyanavaa. ee tika puravalaa form eka submit karanna. sathi 2k athulatha eyaalaa oyaava thoragannavadha nadhdha kiyala email karayi. lokuvata hopes thiyaaganna epaa. dhaen tharaGAya vaedii intern valata.',
      expected: 'ඒ form eke ලොකුවට පුරවන්න දෙයක් නෑ. CV එක upload කරල ඔයාගෙ NIC number එක wage personal details ටිකක් පුරවන්න ටියනවා. ඒ ටික පුරවලා form එක submit කරන්න. සති 2ක් අතුලත එයාලා ඔයාව තොරගන්නවද නද්ද කියල email කරයි. ලොකුවට hopes තියාගන්න එපා. දැන් තරඟය වැඩී intern වලට.',
      
    },
    
   
    {
      tcId: 'Pos_Fun_0024',
      name: ' Request forms with varying degrees of politeness + Multiple spaces',
      input: 'kaeema godak rasayi. oyaage ammata hodhata uyanna puluvan',
      expected: 'කෑම ගොඩක් රසයි. ඔයාගෙ අම්මට හොදට උයන්න පුලුවන්',
    }
  ],
  
  negative: [
    {
      tcId: 'Neg_Fun_0001',
      name: 'simple sentense with common English words + English  short forms',
      input: 'adha raeta thiyana flight eke man USA yanna inNe',
      expected: 'අද රැට තියන flight එකෙ මන් USA යන්න ඉන්නෙ',
    },
    {
      tcId: 'Neg_Fun_0002',
      name: 'Convert a short request phrase',
      input: 'oyaa heta pQQthi naawoth paadama allaganna baeri vevi.',
      expected: 'ඔයා හෙට පංති නාවොත් පාඩම අල්ලගන්න බැරි වෙවි.',
    },
    {
      tcId: 'Neg_Fun_0003',
      name: 'English mixed polite sentence',
      input: 'karunaakaralaa eyaata enna kiyanavadha mage office ekata',
      expected: 'කරුනාකරලා එයාට එන්න කියනවද මගෙ office එකට',
    },
    {
      tcId: 'Neg_Fun_0004',
      name: 'Random letters (no meaning)',
      input: 'dffghjjhklqwjqlfn',
      expected: 'ඩ්ෆ්ෆ්ග්හ්ජ්ඣ්ක්ල්ක්ව්ජ්ක්ල්ෆ්න්',
    },
    {
      tcId: 'Neg_Fun_0005',
      name: 'Unsupported language (English sentence)',
      input: 'I am eating right now.',
      expected: 'I am eating right now.',
    },
    {
      tcId: 'Neg_Fun_0006',
      name: 'Mixed symbols and text',
      input: '/@myplace',
      expected: '/@myplace',
      
    },
    {
      tcId: 'Neg_Fun_0007',
      name: 'Misspelled Singlish word',
      input: 'ayuubohwwn!',
      expected: 'ආයුබෝවන්!',
    },
    {
      tcId: 'Neg_Fun_0008',
      name: 'Question with spacing error',
      input: 'oyamokadhakaranne',
      expected: 'ඔය මොකද කරන්නේ',
    },
    {
      tcId: 'Neg_Fun_0009',
      name: 'Complex slang statement with english words',
      input: 'eyi bro eeka chatch eka alla ganin',
      expected: 'එයි bro ඒක chatch එක අල්ල ගනින්',
    },
    {
      tcId: 'Neg_Fun_0010',
      name: 'capitaliezed words',
      input: 'MEEKA HARIMA LEESII',
      expected: 'මේක හරිම ලස්සනයි',

    }
  ],
  
  ui: {
    tcId: 'Pos_UI_0001',
    name: 'Overflow handling',
    input: 'mama '.repeat(40),
    expected: "මම ".repeat(40),
  }
};

// Helper Functions
class TranslatorPage {
  constructor(page) {
    this.page = page;
  }

  async navigateToSite() {
    await this.page.goto(CONFIG.url);
    await this.page.waitForLoadState('networkidle');
    await this.page.waitForTimeout(CONFIG.timeouts.pageLoad);
  }

  async getInputField() {
    return this.page.getByRole('textbox', { name: CONFIG.selectors.inputField });
  }

  async getOutputField() {
    return this.page
      .locator(CONFIG.selectors.outputContainer)
      .filter({ hasNot: this.page.locator('textarea') })
      .first();
  }

  async clearAndWait() {
    const input = await this.getInputField();
    await input.clear();
    await this.page.waitForTimeout(CONFIG.timeouts.afterClear);
  }

  async typeInput(text) {
    const input = await this.getInputField();
    await input.fill(text);
  }

  async waitForOutput() {
    await this.page.waitForFunction(
      () => {
        const elements = Array.from(
          document.querySelectorAll('.w-full.h-80.p-3.rounded-lg.ring-1.ring-slate-300.whitespace-pre-wrap')
        );
        const output = elements.find(el => {
          const isInputField = el.tagName === 'TEXTAREA' || el.getAttribute('role') === 'textbox';
          return !isInputField && el.textContent && el.textContent.trim().length > 0;
        });
        return output !== undefined;
      },
      { timeout: 10000 }
    );
    await this.page.waitForTimeout(CONFIG.timeouts.translation);
  }

  async getOutputText() {
    const output = await this.getOutputField();
    const text = await output.textContent();
    return text.trim();
  }

  async performTranslation(inputText) {
    await this.clearAndWait();
    await this.typeInput(inputText);
    await this.waitForOutput();
    return await this.getOutputText();
  }
}

// Test Suite
test.describe('SwiftTranslator - Singlish to Sinhala Conversion Tests', () => {
  let translator;

  test.beforeEach(async ({ page }) => {
    translator = new TranslatorPage(page);
    await translator.navigateToSite();
  });

  // Positive Functional Tests
  test.describe('Positive Functional Tests', () => {
    for (const testCase of TEST_DATA.positive) {
      test(`${testCase.tcId} - ${testCase.name}`, async () => {
        const actualOutput = await translator.performTranslation(testCase.input);
        expect(actualOutput).toBe(testCase.expected);
        await translator.page.waitForTimeout(CONFIG.timeouts.betweenTests);
      });
    }
  });

  // Negative Functional Tests
  test.describe('Negative Functional Tests', () => {
    for (const testCase of TEST_DATA.negative) {
      test(`${testCase.tcId} - ${testCase.name}`, async () => {
        const actualOutput = await translator.performTranslation(testCase.input);
        expect(actualOutput).toBe(testCase.expected);
        await translator.page.waitForTimeout(CONFIG.timeouts.betweenTests);
      });
    }
  });

  // UI Test
  test.describe('UI Functionality Tests', () => {
    test(`${TEST_DATA.ui.tcId} - ${TEST_DATA.ui.name}`, async ({ page }) => {
      const translator = new TranslatorPage(page);
      const input = await translator.getInputField();
      const output = await translator.getOutputField();

      await translator.clearAndWait();
      
      // Type partial input
      await input.pressSequentially(TEST_DATA.ui.partialInput, { delay: 150 });
      
      // Wait for partial output
      await page.waitForTimeout(1500);
      
      // Verify partial translation appears
      let outputText = await output.textContent();
      expect(outputText.trim().length).toBeGreaterThan(0);
      
      // Complete typing
      await input.pressSequentially(TEST_DATA.ui.input.substring(TEST_DATA.ui.partialInput.length), { delay: 150 });
      
      // Wait for full translation
      await translator.waitForOutput();
      
      // Verify full translation
      outputText = await translator.getOutputText();
      expect(outputText).toBe(TEST_DATA.ui.expectedFull);
      
      await page.waitForTimeout(CONFIG.timeouts.betweenTests);
    });
  });
});
